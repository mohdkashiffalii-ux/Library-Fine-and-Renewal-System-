/*
 * ============================================================================
 * PROJECT NOTICE & ARCHITECTURE OVERVIEW
 * ============================================================================
 * Project Title : Library Fine and Renewal System
 * Language      : C
 *
 * SYLLABUS & COURSE OUTCOME (CO) MAPPING:
 * ----------------------------------------------------------------------------
 * [CO1] Fine Calculation Flow      : Implemented via dateToDays() & returnBook()
 * [CO2] Renewal & Fine Logic       : Implemented via renewBook() & returnBook()
 * [CO3] Array & Function Reports   : Implemented via generateReports()
 * [CO4] Dynamic Memory & Pointers  : Implemented via malloc(), realloc(), free()
 * [CO5] Modular Book Management    : Implemented via separated single-purpose
 *                                    functions, structures, and File I/O.
 * ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// ============================================================================
// STEP 1: SYSTEM CONFIGURATION CONSTANTS
// ============================================================================
#define MAX_LOAN_DAYS 14        // Standard borrowing period (14 days)
#define MAX_RENEWALS 2          // Maximum times a single loan can be renewed
#define FINE_PER_DAY 5.0        // Late fee rate (Rs. 5.00 per overdue day)
#define DATA_FILE "loans.dat"   // Binary file for persistent storage

// ============================================================================
// STEP 2: DATA STRUCTURES (CO5 - Modularity & Structured Representation)
// ============================================================================
typedef struct {
    int day;
    int month;
    int year;
} Date;

typedef struct {
    int book_id;          // Unique identifier for the book
    int student_id;       // Unique identifier for the student
    Date issue_date;      // Date when book was issued
    Date due_date;        // Calculated return deadline
    Date return_date;     // Actual date when book was returned
    int is_returned;      // Status flag: 0 = Active Loan, 1 = Returned
    int renewal_count;    // Number of times renewed (0 to MAX_RENEWALS)
    float fine_amount;    // Calculated overdue fine
} BookLoan;

// ============================================================================
// STEP 3: FUNCTION PROTOTYPES (Modular Design)
// ============================================================================
// Date & Fine Calculation Utilities (CO1)
int isLeapYear(int year);
int daysInMonth(int month, int year);
long dateToDays(Date d);
Date addDays(Date d, int days);

// Core Loan Operations (CO2, CO4, CO5)
void issueBook(BookLoan **loans, int *count, int *capacity);
void renewBook(BookLoan *loans, int count);
void returnBook(BookLoan *loans, int count);

// Reporting & Display Functions (CO3)
void displayAllLoans(const BookLoan *loans, int count);
void generateReports(const BookLoan *loans, int count);

// File Handling Functions (Persistence)
void saveLoansToFile(const BookLoan *loans, int count);
void loadLoansFromFile(BookLoan **loans, int *count, int *capacity);

// ============================================================================
// STEP 4: MAIN DRIVER FUNCTION (Menu Loop & Dynamic Memory Initialization)
// ============================================================================
int main() {
    BookLoan *loans = NULL;     // Pointer to dynamically allocated array (CO4)
    int count = 0;              // Current number of stored loan records
    int capacity = 2;           // Initial heap capacity (grows dynamically)
    int choice;

    // [NOTICE - CO4]: Allocate initial dynamic memory on the heap
    loans = (BookLoan *)malloc(capacity * sizeof(BookLoan));
    if (loans == NULL) {
        printf("[ERROR] Initial memory allocation failed!\n");
        return 1;
    }

    // [NOTICE - File Handling]: Restore previous session records if file exists
    loadLoansFromFile(&loans, &count, &capacity);

    do {
        printf("\n====================================================\n");
        printf("          LIBRARY FINE AND RENEWAL SYSTEM           \n");
        printf("====================================================\n");
        printf("  1. Issue New Book Loan (Dynamic Allocation)\n");
        printf("  2. Renew Existing Book Loan (Decision Logic)\n");
        printf("  3. Return Book & Calculate Fine (Fine Flow)\n");
        printf("  4. Display All Book Loans\n");
        printf("  5. Generate Defaulter & Revenue Reports\n");
        printf("  6. Save Records & Exit\n");
        printf("====================================================\n");
        printf("Enter your choice (1-6): ");

        if (scanf("%d", &choice) != 1) {
            while (getchar() != '\n'); // Clear invalid input buffer
            choice = 0;
        }

        switch (choice) {
            case 1:
                issueBook(&loans, &count, &capacity);
                break;
            case 2:
                renewBook(loans, count);
                break;
            case 3:
                returnBook(loans, count);
                break;
            case 4:
                displayAllLoans(loans, count);
                break;
            case 5:
                generateReports(loans, count);
                break;
            case 6:
                saveLoansToFile(loans, count);
                printf("[SUCCESS] All records saved to '%s'. Exiting...\n", DATA_FILE);
                break;
            default:
                printf("[WARNING] Invalid option. Please enter a number from 1 to 6.\n");
        }
    } while (choice != 6);

    // [NOTICE - CO4]: Release dynamically allocated memory before exit
    free(loans);
    loans = NULL;
    return 0;
}

// ============================================================================
// STEP 5: DATE & FINE CALCULATION HELPER FUNCTIONS (CO1)
// ============================================================================

/*
 * FUNCTION NOTICE: isLeapYear
 * Purpose: Determines whether a given year is a leap year.
 */
int isLeapYear(int year) {
    return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
}

/*
 * FUNCTION NOTICE: daysInMonth
 * Purpose: Returns the exact number of days in a given month and year.
 */
int daysInMonth(int month, int year) {
    int days[] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    if (month < 1 || month > 12) return 30;
    if (month == 2 && isLeapYear(year)) {
        return 29;
    }
    return days[month];
}

/*
 * FUNCTION NOTICE: dateToDays (CO1)
 * Purpose: Converts a calendar Date (DD/MM/YYYY) into total elapsed days
 *          so exact overdue days can be calculated via subtraction.
 */
long dateToDays(Date d) {
    long total_days = d.day;
    for (int y = 1; y < d.year; y++) {
        total_days += isLeapYear(y) ? 366 : 365;
    }
    for (int m = 1; m < d.month; m++) {
        total_days += daysInMonth(m, d.year);
    }
    return total_days;
}

/*
 * FUNCTION NOTICE: addDays (CO1)
 * Purpose: Adds a specified number of days to a Date (used to compute
 *          initial due dates and extended renewal due dates).
 */
Date addDays(Date d, int days) {
    d.day += days;
    while (d.day > daysInMonth(d.month, d.year)) {
        d.day -= daysInMonth(d.month, d.year);
        d.month++;
        if (d.month > 12) {
            d.month = 1;
            d.year++;
        }
    }
    return d;
}

// ============================================================================
// STEP 6: CORE LOAN MANAGEMENT FUNCTIONS (CO2, CO4, CO5)
// ============================================================================

/*
 * FUNCTION NOTICE: issueBook (CO4 & CO5)
 * Purpose: Creates a new loan record. Uses double pointers (**loans) and
 *          realloc() to dynamically expand memory when capacity is full.
 */
void issueBook(BookLoan **loans, int *count, int *capacity) {
    // Check if dynamic array needs expansion
    if (*count >= *capacity) {
        *capacity *= 2;
        BookLoan *temp = (BookLoan *)realloc(*loans, (*capacity) * sizeof(BookLoan));
        if (temp == NULL) {
            printf("[ERROR] Memory reallocation failed! Cannot add more loans.\n");
            return;
        }
        *loans = temp;
        printf("[SYSTEM NOTICE] Dynamic array expanded to capacity: %d\n", *capacity);
    }

    BookLoan *newLoan = &(*loans)[*count];

    printf("\n--- ISSUE NEW BOOK LOAN ---\n");
    printf("Enter Book ID               : ");
    scanf("%d", &newLoan->book_id);
    printf("Enter Student ID            : ");
    scanf("%d", &newLoan->student_id);
    printf("Enter Issue Date (DD MM YYYY): ");
    scanf("%d %d %d", &newLoan->issue_date.day, &newLoan->issue_date.month, &newLoan->issue_date.year);

    // Initialize default loan fields
    newLoan->due_date = addDays(newLoan->issue_date, MAX_LOAN_DAYS);
    newLoan->return_date = (Date){0, 0, 0};
    newLoan->is_returned = 0;
    newLoan->renewal_count = 0;
    newLoan->fine_amount = 0.0;

    (*count)++;
    printf("[SUCCESS] Book Issued! Due Date is: %02d/%02d/%04d\n",
           newLoan->due_date.day, newLoan->due_date.month, newLoan->due_date.year);
}

/*
 * FUNCTION NOTICE: renewBook (CO2 - Decision Logic)
 * Purpose: Validates renewal eligibility based on two rules:
 *          1. Renewal count must be less than MAX_RENEWALS (2).
 *          2. Book must NOT already be overdue on the current date.
 */
void renewBook(BookLoan *loans, int count) {
    int book_id, student_id;
    Date current_date;

    printf("\n--- RENEW BOOK LOAN ---\n");
    printf("Enter Book ID                 : ");
    scanf("%d", &book_id);
    printf("Enter Student ID              : ");
    scanf("%d", &student_id);

    for (int i = 0; i < count; i++) {
        if (loans[i].book_id == book_id && loans[i].student_id == student_id && loans[i].is_returned == 0) {
            // Rule 1: Check maximum renewal limit
            if (loans[i].renewal_count >= MAX_RENEWALS) {
                printf("[DENIED] Maximum renewal limit (%d) already reached.\n", MAX_RENEWALS);
                return;
            }

            printf("Enter Current Date (DD MM YYYY): ");
            scanf("%d %d %d", &current_date.day, &current_date.month, &current_date.year);

            // Rule 2: Check if book is already overdue
            long overdue_days = dateToDays(current_date) - dateToDays(loans[i].due_date);
            if (overdue_days > 0) {
                printf("[DENIED] Book is overdue by %ld days. Return book and pay Rs. %.2f fine.\n",
                       overdue_days, overdue_days * FINE_PER_DAY);
                return;
            }

            // Approve renewal and extend due date
            loans[i].due_date = addDays(loans[i].due_date, MAX_LOAN_DAYS);
            loans[i].renewal_count++;
            printf("[APPROVED] Book renewed! New Due Date: %02d/%02d/%04d (Renewals: %d/%d)\n",
                   loans[i].due_date.day, loans[i].due_date.month, loans[i].due_date.year,
                   loans[i].renewal_count, MAX_RENEWALS);
            return;
        }
    }
    printf("[NOT FOUND] No active loan found for Book ID %d and Student ID %d.\n", book_id, student_id);
}

/*
 * FUNCTION NOTICE: returnBook (CO1 & CO2 - Fine Calculation & Return Flow)
 * Purpose: Marks an active loan as returned, compares return_date against
 *          due_date, and computes fine_amount if overdue.
 */
void returnBook(BookLoan *loans, int count) {
    int book_id, student_id;

    printf("\n--- RETURN BOOK & CALCULATE FINE ---\n");
    printf("Enter Book ID                : ");
    scanf("%d", &book_id);
    printf("Enter Student ID             : ");
    scanf("%d", &student_id);

    for (int i = 0; i < count; i++) {
        if (loans[i].book_id == book_id && loans[i].student_id == student_id && loans[i].is_returned == 0) {
            printf("Enter Return Date (DD MM YYYY): ");
            scanf("%d %d %d", &loans[i].return_date.day, &loans[i].return_date.month, &loans[i].return_date.year);

            long overdue_days = dateToDays(loans[i].return_date) - dateToDays(loans[i].due_date);

            if (overdue_days > 0) {
                loans[i].fine_amount = overdue_days * FINE_PER_DAY;
                printf("[OVERDUE] Returned %ld days late. Fine Applied: Rs. %.2f\n",
                       overdue_days, loans[i].fine_amount);
            } else {
                loans[i].fine_amount = 0.0;
                printf("[ON TIME] Book returned within due date. Fine: Rs. 0.00\n");
            }

            loans[i].is_returned = 1;
            return;
        }
    }
    printf("[NOT FOUND] No active loan found for Book ID %d and Student ID %d.\n", book_id, student_id);
}

// ============================================================================
// STEP 7: REPORTING & DISPLAY FUNCTIONS (CO3)
// ============================================================================

/*
 * FUNCTION NOTICE: displayAllLoans (CO3)
 * Purpose: Traverses the dynamic array using pointers to print all records.
 */
void displayAllLoans(const BookLoan *loans, int count) {
    if (count == 0) {
        printf("\n[INFO] No book loan records available.\n");
        return;
    }

    printf("\n------------------------------------------------------------------------------------------\n");
    printf("%-8s %-10s %-12s %-12s %-12s %-10s %-8s %-10s\n",
           "BookID", "StudentID", "IssueDate", "DueDate", "ReturnDate", "Status", "Renewals", "Fine");
    printf("------------------------------------------------------------------------------------------\n");

    for (int i = 0; i < count; i++) {
        char issueStr[15], dueStr[15], retStr[15];
        sprintf(issueStr, "%02d/%02d/%04d", loans[i].issue_date.day, loans[i].issue_date.month, loans[i].issue_date.year);
        sprintf(dueStr, "%02d/%02d/%04d", loans[i].due_date.day, loans[i].due_date.month, loans[i].due_date.year);

        if (loans[i].is_returned) {
            sprintf(retStr, "%02d/%02d/%04d", loans[i].return_date.day, loans[i].return_date.month, loans[i].return_date.year);
        } else {
            strcpy(retStr, "Pending");
        }

        printf("%-8d %-10d %-12s %-12s %-12s %-10s %-8d Rs.%.2f\n",
               loans[i].book_id,
               loans[i].student_id,
               issueStr,
               dueStr,
               retStr,
               loans[i].is_returned ? "Returned" : "Active",
               loans[i].renewal_count,
               loans[i].fine_amount);
    }
    printf("------------------------------------------------------------------------------------------\n");
}

/*
 * FUNCTION NOTICE: generateReports (CO3 - Defaulter & Revenue Analytics)
 * Purpose: Generates two management reports from the loan array:
 *          1. Defaulter Report: Lists students with paid late fines or
 *             currently overdue active books.
 *          2. Revenue Report: Summarizes collected vs. pending fine revenue.
 */
void generateReports(const BookLoan *loans, int count) {
    if (count == 0) {
        printf("\n[INFO] No records available to generate reports.\n");
        return;
    }

    Date today;
    float collected_revenue = 0.0;
    float pending_revenue = 0.0;
    int defaulter_count = 0;

    printf("\nEnter Reference/Today's Date (DD MM YYYY): ");
    scanf("%d %d %d", &today.day, &today.month, &today.year);
    long today_days = dateToDays(today);

    printf("\n==================== DEFAULTER REPORT ====================\n");
    printf("%-10s %-8s %-12s %-14s %-15s\n", "StudentID", "BookID", "DueDate", "OverdueStatus", "FineAmount");
    printf("----------------------------------------------------------\n");

    for (int i = 0; i < count; i++) {
        if (loans[i].is_returned == 1) {
            collected_revenue += loans[i].fine_amount;
            if (loans[i].fine_amount > 0) {
                printf("%-10d %-8d %02d/%02d/%04d   %-14s Rs.%.2f (Paid)\n",
                       loans[i].student_id, loans[i].book_id,
                       loans[i].due_date.day, loans[i].due_date.month, loans[i].due_date.year,
                       "Returned Late", loans[i].fine_amount);
                defaulter_count++;
            }
        } else {
            long overdue = today_days - dateToDays(loans[i].due_date);
            if (overdue > 0) {
                float accrued = overdue * FINE_PER_DAY;
                pending_revenue += accrued;
                printf("%-10d %-8d %02d/%02d/%04d   %ld days late   Rs.%.2f (Unpaid)\n",
                       loans[i].student_id, loans[i].book_id,
                       loans[i].due_date.day, loans[i].due_date.month, loans[i].due_date.year,
                       overdue, accrued);
                defaulter_count++;
            }
        }
    }

    if (defaulter_count == 0) {
        printf("No defaulters found.\n");
    }

    printf("\n===================== REVENUE REPORT =====================\n");
    printf("Total Defaulter Cases        : %d\n", defaulter_count);
    printf("Collected Fine Revenue       : Rs. %.2f\n", collected_revenue);
    printf("Pending Uncollected Fines    : Rs. %.2f\n", pending_revenue);
    printf("Total Projected Fine Revenue : Rs. %.2f\n", collected_revenue + pending_revenue);
    printf("==========================================================\n");
}

// ============================================================================
// STEP 8: FILE HANDLING FUNCTIONS (Data Persistence)
// ============================================================================

/*
 * FUNCTION NOTICE: saveLoansToFile
 * Purpose: Writes the total loan count and dynamic array block to disk.
 */
void saveLoansToFile(const BookLoan *loans, int count) {
    FILE *fp = fopen(DATA_FILE, "wb");
    if (fp == NULL) {
        printf("[ERROR] Unable to open file '%s' for saving.\n", DATA_FILE);
        return;
    }
    fwrite(&count, sizeof(int), 1, fp);
    if (count > 0) {
        fwrite(loans, sizeof(BookLoan), count, fp);
    }
    fclose(fp);
}

/*
 * FUNCTION NOTICE: loadLoansFromFile
 * Purpose: Reads saved loan records from disk at startup and resizes the
 *          dynamic heap buffer if saved records exceed initial capacity.
 */
void loadLoansFromFile(BookLoan **loans, int *count, int *capacity) {
    FILE *fp = fopen(DATA_FILE, "rb");
    if (fp == NULL) {
        return; // First run: no saved file exists yet
    }

    int saved_count = 0;
    if (fread(&saved_count, sizeof(int), 1, fp) == 1 && saved_count > 0) {
        if (saved_count > *capacity) {
            *capacity = saved_count;
            BookLoan *temp = (BookLoan *)realloc(*loans, (*capacity) * sizeof(BookLoan));
            if (temp != NULL) {
                *loans = temp;
            }
        }
        *count = fread(*loans, sizeof(BookLoan), saved_count, fp);
        printf("[SYSTEM NOTICE] Loaded %d existing record(s) from '%s'.\n", *count, DATA_FILE);
    }
    fclose(fp);
}